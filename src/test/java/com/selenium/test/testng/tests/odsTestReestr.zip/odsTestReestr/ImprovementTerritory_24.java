package com.selenium.test.testng.tests.odsTestReestr;

import com.selenium.test.testng.tests.odsTestReestr.TestProcedures;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selectors.byXpath;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.executeJavaScript;

/**
 * Created by Vyacheslav on 27.03.2017.
 */
public class ImprovementTerritory_24 extends TestProcedures {

    @BeforeClass
    public void befClass() {
        autorisationUser();
    }

    @BeforeMethod
    public void befTest() {
        openOGHReestr();
    }

    @Test
    public void improvementTerritory1()  {
        clickImprovementTerritory_24();
        objectNull();
        $(byXpath(".//*[@id='props']/div[2]/div[1]/div/div[2]")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='auto-okrug_id']/div")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='auto-district_id']/div")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='props']/div[4]/div[1]/div/div[2]")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='props']/div[5]/div[1]/div/div[4]")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='props']/div[2]/div[1]/div/div[1]/hr[2]")).waitUntil(visible,25000).exists();
        $(byXpath(".//*[@id='props']/div[4]/div[1]/div/div[1]/hr[2]")).waitUntil(visible,25000).exists();
        $(byXpath(".//*[@id='props']/div[5]/div[1]/div/div[3]/hr[2]")).waitUntil(visible,25000).exists();
        executeJavaScript("$('.content').animate({scrollTop: $(\"#territory_type_id>div\").offset().top - 100}, 1000);");
        $(byXpath(".//*[@id='props']/div[6]/div/div[1]/div[1]/div")).waitUntil(visible,25000).shouldHave(text("обязательный список"));
        $(byXpath(".//*[@id='characteristics']/div[1]/div[1]/div/div[2]")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='characteristics']/div[1]/div[3]/div/div[4]")).waitUntil(visible,25000).shouldHave(text("обязательное поле"));
        $(byXpath(".//*[@id='characteristics']/div[1]/div[1]/div/div[1]/hr[2]")).waitUntil(visible,25000).exists();
        $(byXpath(".//*[@id='characteristics']/div[1]/div[3]/div/div[3]/hr[2]")).waitUntil(visible,25000).exists();
        executeJavaScript("$('.content').animate({scrollTop: $(\"#passport_id\").offset().top - 100}, 1000);");
        $(byXpath(".//*[@id='characteristics']/div[4]/div[2]/div[1]/div")).waitUntil(visible,25000).shouldHave(text("обязательный список"));

    }

    @Test
    public void requiredImprovementTerritory() {
        clickImprovementTerritory_24();
        objectNull();
        Reestr_Name.sendKeys("Автотест1");
        $(byXpath(".//*[@id='auto-okrug_id']/span/span[1]/span/span[2]")).click();
        $(byXpath("html/body/span/span/span[1]/input")).sendKeys("ЮЗАО");
        $$(byXpath(".//*[@id='select2-okrug_id-results']/li")).findBy(text("ЮЗАО")).click();
        $(byXpath(".//*[@id='auto-district_id']/span/span[1]/span/span[2]")).click();
        $(byXpath("html/body/span/span/span[1]/input")).sendKeys("Южн");
        $$(byXpath(".//*[@id='select2-district_id-results']/li")).findBy(text("Южное Бутово")).click();
        $("#address_text").sendKeys("Тестовая улица");
        $("#territory_type_id>div>button").click();
        $$(byXpath("html/body/div[26]/div/div/div")).findBy(text("Основные")).click();
        executeJavaScript("$('.content').animate({scrollTop: $(\"#territory_type_id>div\").offset().top - 100}, 1000);");
        $(byXpath(".//*[@id='props']/div[6]/div/div[1]/div[1]/button[1]")).click();
        $(byXpath("//input[@id='addressdetails-undefined--26088']")).sendKeys("лом");
        //$$(byXpath(".//*[@id='add_assoc_address']/div")).findBy("#address_details").sendKeys("лом");
        //$(".addressComboBox").click();
        //$(byId("address_details")).sendKeys("лом");
        //$$(byXpath(".//*[@id='address_details']/div[2]")).findBy(text("Ломоносовский просп., 32")).click();
        //$(byXpath("html/body/div[15]/div/div[1]/div/div/div[2]/button[1]")).click();
        $("#total_clean_area").sendKeys("85");
        $("#greenery_clean_category_id>div>button").click();
        $(byText("I-я кат.")).click();
        executeJavaScript("$('.content').animate({scrollTop: $(\"#passport_id\").offset().top - 100}, 1000);");
        $(byXpath(".//*[@id='characteristics']/div[4]/div[2]/div[1]/button[1]")).click();
        $("#buildings_type_id>div>button").click();


    }

    @Test
    public void viewImprovementTerritoryProject() {
        clickImprovementTerritory_24();
        Id_or_Name.sendKeys("2268952");
        Status_Combo_Box.click();
        Status_Combo_Box_List.find(text("Проект")).click();
        //$(byText("Проект")).click();
        Search_Button.click();
        $(byText("2268952")).click();
        Header_Card.shouldHave(text("Даев пер. 12/16, Даев пер. 14"));
    }

    @Test
    public void viewImprovementTerritoryApproved() {
        clickImprovementTerritory_24();
        Id_or_Name.sendKeys("2150128");
        Search_Button.click();
        $(byText("2150128")).click();
        Header_Card.shouldHave(text("Чаянова ул. 14 ID 2150128"));
    }
}
