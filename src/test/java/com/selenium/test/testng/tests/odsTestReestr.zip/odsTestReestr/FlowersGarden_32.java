package com.selenium.test.testng.tests.odsTestReestr;

import com.selenium.test.testng.tests.odsTestReestr.TestProcedures;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

/**
 * Created by Vyacheslav on 27.03.2017.
 */
public class FlowersGarden_32 extends TestProcedures {

    @BeforeClass
    public void befClass() {
        autorisationUser();
    }

    @BeforeMethod
    public void befTest() {
        openOGHReestr();
    }

    @Test
    public void requiredParametersFlowersGarden() {
        clickFlowersGarden_32();
        createObject();
        clickSave();
        $(byText("Не указана геометрия объекта. Отобразите геометрию ОГХ перед сохранением."));
    }

    @Test
    public void viewFlowersGardenProject() {
        clickFlowersGarden_32();
        Id_or_Name.sendKeys("2268945");
        Status_Combo_Box.click();
        Status_Combo_Box_List.find(text("Проект")).click();
        //$(byText("Проект")).click();
        Search_Button.click();
        $(byText("2268945")).click();
        Header_Card.shouldHave(text("Уч. №<неопределено>, раст. №<неопределено>"));
    }

    @Test
    public void viewFlowersGardenApproved() {
        clickFlowersGarden_32();
        Id_or_Name.sendKeys("2230540");
        Search_Button.click();
        $(byText("2230540")).click();
        Header_Card.shouldHave(text("Уч. №1, раст. №1"));
    }
}
