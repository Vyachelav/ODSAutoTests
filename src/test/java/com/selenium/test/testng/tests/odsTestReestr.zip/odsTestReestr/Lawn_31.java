package com.selenium.test.testng.tests.odsTestReestr;

import com.selenium.test.testng.tests.odsTestReestr.TestProcedures;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selectors.byText;
import static com.codeborne.selenide.Selenide.$;

/**
 * Created by Vyacheslav on 27.03.2017.
 */
public class Lawn_31 extends TestProcedures {

    @BeforeClass
    public void befClass() {
        autorisationUser();
    }

    @BeforeMethod
    public void befTest() {
        openOGHReestr();
    }

    @Test
    public void requiredParametersLawn() {
        clickLawn_31();
        createObject();
        clickSave();
        $(byText("Не указана геометрия объекта. Отобразите геометрию ОГХ перед сохранением."));
    }

    @Test
    public void viewLawnProject() {
        clickLawn_31();
        Id_or_Name.sendKeys("2269634");
        Status_Combo_Box.click();
        Status_Combo_Box_List.find(text("Проект")).click();
        //$(byText("Проект")).click();
        Search_Button.click();
        $(byText("2269634")).click();
        Header_Card.shouldHave(text("Уч. №<неопределено> "));
    }

    @Test
    public void viewLawnApproved() {
        clickLawn_31();
        Id_or_Name.sendKeys("2239622");
        Search_Button.click();
        $(byText("2239622")).click();
        Header_Card.shouldHave(text("Уч. №5"));
    }


}
